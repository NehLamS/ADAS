function dxdt = derivs(simulation,vehicle,driver,state,varargin)
% derivs: calculates state derivatives 
% 
% Usage:
% dxdt = derivs(simulation,vehicle,state,driver, varargin)
% simulation: a structure about the simulation environment, 
% vehicle: a structure that describes the properties of the vehicle being simulated,
% state: states being used in the simulation
% varargin: type, for the 2-wheel model, varargin = Fy, for 4-wheel model, 
%           varargin{1} = Fy, varargin{2} = Fx, and varargin{3} = delta
% output: a vector of the state derivatives of the system.

% Wheel number
lf = 1; rf = 2; lr = 3; rr = 4;

% Define derivatives with respect to model type
switch lower(simulation.vmodel)
    % 2-wheel Model
    case 'bike'             
        if all(isfield(vehicle, {'l_f', 'l_r', 'm', 'Izz'})) && ...
            length(varargin{1}) == 4 && isfield(simulation, 'speed')
            if length(state) == 2
                vx = simulation.speed;
            else
                vx = state(3);
            end
            psidot = state(2);
            l_f = vehicle.l_f; l_r = vehicle.l_r; m = vehicle.m; Izz = vehicle.Izz;
            Fy = varargin{1};
            Fyf = Fy(lf) + Fy(rf);
            Fyr = Fy(lr) + Fy(rr);
            psiddot = (l_f*Fyf - l_r*Fyr) / Izz;
            vydot = (Fyf + Fyr)/m - psidot*vx;
            dxdt(1) = vydot;
            dxdt(2) = psiddot;
            % Additional states when following path
            switch lower(driver.mode)
                case 'path'
                    trackInfo = varargin{4};
                    vy = state(1); delta_psi = state(10); s = state(8);
                    % Calculate the current curvature
                    rhoInv = track(trackInfo,s);
                    sdot = vx*cos(delta_psi) - vy*sin(delta_psi);
                    edot = vy*cos(delta_psi) + vx*sin(delta_psi);
                    delta_psidot = psidot - sdot*rhoInv;
                    dxdt(8) = sdot;
                    dxdt(9) = edot;
                    dxdt(10) = delta_psidot;
                    dxdt(3:7) = 0;
                otherwise
            end
        else                            
            error('Missing bike model deriv parameters');
        end

    case 'fourwheel'
        if all(isfield(vehicle, {'l_f', 'l_r', 'm', 'Izz', 'd'}))
            % Get the variables we will need
            if length(state) == 2
                vx = simulation.speed;
            else
                vx = state(3);
            end
            vy = state(1); psidot = state(2);
            l_f = vehicle.l_f; l_r = vehicle.l_r; m = vehicle.m; 
            Izz = vehicle.Izz; d = vehicle.d;
            Fy = varargin{1}; Fx = varargin{2}; delta = varargin{3};
            % y-direction
            Fyr = Fy(lr) + Fy(rr);
            Fyf = Fy(lf)*cos(delta(lf)) + Fx(lf)*sin(delta(lf)) + ...
                Fy(rf)*cos(delta(rf)) + Fx(rf)*sin(delta(rf));
            vydot = (Fyf + Fyr)/m - psidot*vx;
            % x-direction
            Fxr = Fx(lr) + Fx(rr);
            Fxf = Fx(lf)*cos(delta(lf)) + Fx(rf)*cos(delta(rf)) - ...
                Fy(lf)*sin(delta(lf)) - Fy(rf)*sin(delta(rf));
            vxdot = (Fxf + Fxr)/m + psidot*vy;
            % Calculate moments
            Fa = Fy(lf)*cos(delta(lf)) + Fy(rf)*cos(delta(rf)) + ...
                Fx(lf)*sin(delta(lf)) + Fx(rf)*sin(delta(rf));
            Fb = Fy(lr) + Fy(rr);
            Fd = Fx(rr) - Fx(lr) + Fx(rf)*cos(delta(rf)) - ...
                Fx(lf)*cos(delta(lf)) + Fy(lf)*sin(delta(lf)) - ...
                Fy(rf)*sin(delta(rf));
            psiddot = (l_f*Fa - l_r*Fb + d/2*Fd)/Izz;
            dxdt(1) = vydot;
            dxdt(2) = psiddot;
            if length(state) > 2
                dxdt(3) = vxdot;
            end
            % Additional states when following path
            switch lower(driver.mode)
                case 'path'
                    trackInfo = varargin{4};
                    vy = state(1); delta_psi = state(10); s = state(8);
                    Re = vehicle.Re; Jw = vehicle.Jw;
                    % Calculate the current curvature
                    rhoInv = track(trackInfo,s);
                    sdot = vx*cos(delta_psi) - vy*sin(delta_psi);
                    edot = vy*cos(delta_psi) + vx*sin(delta_psi);
                    delta_psidot = psidot - sdot*rhoInv;
                    dxdt(8) = sdot;
                    dxdt(9) = edot;
                    dxdt(10) = delta_psidot;
                    if length(varargin) > 4
                        Tq = varargin{5};
                        for w = lf:rr
                            wdot(w) = (Tq(w) - Re*Fx(w))/Jw;
                        end
                        dxdt(4:7) = wdot;
                    else
                        dxdt(4:7) = 0;
                    end
                otherwise
                    % Don't need to add states
            end
        else
            error('Missing fourwheel model deriv parameters');
        end
    otherwise
        error('Not a valid vehicle model')
end
