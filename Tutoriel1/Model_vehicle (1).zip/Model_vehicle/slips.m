function varargout = slips(simulation,vehicle,state,delta)
% calculates slip angles based on vehicle model
% 
% Usage: outputVariable = slipangles(simulation,vehicle,state,delta) 
% simulation: a structure about the simulation environment, 
% vehicle: a structure that describes the properties of the vehicle being simulated,
% state and delta: the current vehicle state and driver input, respectively.  
% output: slip angles returned in a structure that will change, depending on the model
%         being used to calculate the slip angles.


% Wheel number
lf = 1; rf = 2; lr = 3; rr = 4;

% Define slip with respect to model type

switch lower(simulation.vmodel)
    % Using the bicycle model
    case 'bike'
        if isfield(simulation, 'speed') && ... 
            all(isfield(vehicle, {'l_f', 'l_r'})) && length(delta) == 4 
            
            vy = state(1); psidot = state(2);
            if length(state) == 2
                vx = simulation.speed;
            else
                vx = state(3);
            end
            l_f = vehicle.l_f; l_r = vehicle.l_r;
            alpha(lf) = ((vy + l_f*psidot) / vx) - delta(lf);
            alpha(rf) = ((vy + l_f*psidot) / vx) - delta(rf);
            alpha(lr) = (vy - l_r*psidot) / vx;
            alpha(rr) = (vy - l_r*psidot) / vx;
            varargout{1} = alpha;
        else
            error('Missing bike model slip angle parameters')
        end
    
    case 'fourwheel'
        if all(isfield(vehicle, {'l_f', 'l_r', 'd', 'Re'})) && length(delta) == 4
            
            vy = state(1); psidot = state(2);
            if length(state) == 2
                vx = simulation.speed;
            else
                vx = state(3);
            end
            l_f = vehicle.l_f; l_r = vehicle.l_r; d = vehicle.d; Re = vehicle.Re;
            alpha(lf) = atan((vy + l_f*psidot) / (vx - d/2*psidot)) - delta(lf);
            alpha(rf) = atan((vy + l_f*psidot) / (vx + d/2*psidot)) - delta(rf);
            alpha(lr) = atan((vy - l_r*psidot) / (vx - d/2*psidot));
            alpha(rr) = atan((vy - l_r*psidot) / (vx + d/2*psidot));
            varargout{1} = alpha;
              
            if length(state) > 2
                v(lf) = (vx - d/2*psidot)*cos(delta(lf)) + (vy + l_f*psidot)*sin(delta(lf));
                v(rf) = (vx + d/2*psidot)*cos(delta(rf)) + (vy + l_f*psidot)*sin(delta(rf));
                v(lr) = vx - d/2*psidot;
                v(rr) = vx + d/2*psidot;
                w(lf) = state(4); w(rf) = state(5); w(lr) = state(6); w(rr) = state(7);
                for wheel = lf:rr
                    kappa(wheel) = (Re*w(wheel) - v(wheel))/v(wheel);
                end
                varargout{2} = kappa;
            end
        else
            error('Missing fourwheel model slip angle parameters')
        end
    otherwise
        error('Not a valid vehicle model')
end
