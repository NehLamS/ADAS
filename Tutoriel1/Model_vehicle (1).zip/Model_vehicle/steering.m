function delta = steering(simulation,driver,state,simtime)
% steering: calculates desired input steering behavior
% Usage: delta = steering(simulation,driver,state,simtime) 
% simulation: a structure about the simulation environment, 
% simtime: the time at which the steering input is desired. 
% delta: a vector with the elements enumerated in the standard order.

% Wheel number
lf = 1; rf = 2; lr = 3; rr = 4;

% Define steering with respect to type of maneuver
switch lower(driver.mode)
    % Step input
    case 'step'             
        if all(isfield(driver, {'delta0', 'deltaf', 'steertime'})) 
            if simtime < driver.steertime
                delta(lf) = driver.delta0;
                delta(rf) = driver.delta0;
                delta(lr) = 0;
                delta(rr) = 0;
            else
                delta(lf) = driver.deltaf;
                delta(rf) = driver.deltaf;
                delta(lr) = 0;
                delta(rr) = 0;
            end
        else                            
            error('Missing step model steering parameters');
        end
    
    case 'data'    
        if all(isfield(driver, {'t_exp', 'delta_exp'}))
            delta(lf) = interp1q(driver.t_exp, driver.delta_exp, simtime);
            delta(rf) = interp1q(driver.t_exp, driver.delta_exp, simtime);
            delta(lr) = 0;
            delta(rr) = 0;
        else                            
            error('Missing data model steering parameters');
        end
        
    % Ramp input
    case 'ramp'             
        if all(isfield(driver, {'delta0', 'steertime', 'deltaramp'})) 
            if simtime < driver.steertime
                delta(lf) = driver.delta0;
                delta(rf) = driver.delta0;
                delta(lr) = 0;
                delta(rr) = 0;
            else
                delta(lf) = (simtime - driver.steertime)*driver.deltaramp ...
                    + driver.delta0;
                delta(rf) = (simtime - driver.steertime)*driver.deltaramp ...
                    + driver.delta0;
                delta(lr) = 0;
                delta(rr) = 0;
            end
        else                            
            error('Missing step model steering parameters');
        end
        
    % Path tracking
    case 'path'
        if all(isfield(driver, {'Ke', 'Kpsi'}))
            e = state(9); delta_psi = state(10);
            Ke = driver.Ke; Kpsi = driver.Kpsi;
            delta(lf) = -Ke*e - Kpsi*delta_psi;
            delta(rf) = -Ke*e - Kpsi*delta_psi;
            delta(lr) = 0;
            delta(rr) = 0;
        else
            error('Missing path model steering parameters');
        end
        
    % Drifting
    case 'drifting'
        if all(isfield(driver, {'deltaEq', 'vyEq', 'psidotEq', 'Kvy', 'Kpsidot'}))
            deltaEq = driver.deltaEq; vyEq = driver.vyEq; psidotEq = driver.psidotEq;
            Kvy = driver.Kvy; Kpsidot = driver.Kpsidot;
            vy = state(1); psidot = state(2);
            deltadelta = -Kvy*(vy - vyEq) - Kpsidot*(psidot - psidotEq);
            delta(lf) = deltaEq + deltadelta;
            delta(rf) = deltaEq + deltadelta;
            delta(lr) = 0;
            delta(rr) = 0;
        else
            error('Missing path model steering parameters');
        end

    otherwise
        error('Not a valid drive mode')
end
